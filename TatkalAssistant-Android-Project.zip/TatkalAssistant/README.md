# Tatkal Assistant (Android)

A lightweight Android companion app for preparing a Tatkal booking. It includes:
- Daily Tatkal opening countdown (AC 10:00 AM; Sleeper/2S 11:00 AM)
- Journey station/date fields and locally saved station codes
- Manual booking checklist
- Button to open the official IRCTC train-search page

## Important limitations
This is an independent companion app, not an IRCTC client and not affiliated with Indian Railways/IRCTC. It does not query live seat availability, reserve seats, autofill IRCTC forms, or submit bookings. CAPTCHA, OTP, passenger review, and payment must be completed by the user on IRCTC. Never share IRCTC passwords, OTPs, or UPI PINs with this app.

## Build APK
1. Open this folder in Android Studio (Giraffe or newer).
2. Allow Gradle sync; install Android SDK Platform 35 if prompted.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will create `app/build/outputs/apk/debug/app-debug.apk`.

Package: `com.tatkalsistant.app` · Min Android: 6.0 (API 23)
