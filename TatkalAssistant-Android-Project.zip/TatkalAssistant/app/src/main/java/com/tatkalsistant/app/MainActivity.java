package com.tatkalsistant.app;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {
    private final Handler handler = new Handler();
    private TextView countdown, dateText, status;
    private RadioGroup classGroup;
    private Calendar journey = Calendar.getInstance();
    private int hour = 11;
    private Runnable ticker;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("tatkal_local", MODE_PRIVATE);
        journey.set(Calendar.HOUR_OF_DAY, 0); journey.set(Calendar.MINUTE, 0);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(18), dp(18), dp(18), dp(20)); root.setBackgroundColor(0xFFF4F7FB);
        ScrollView scroll = new ScrollView(this); scroll.addView(root);
        TextView brand = text("🚆  TATKAL ASSISTANT", 23, 0xFF102A43, true); root.addView(brand);
        TextView sub = text("Your personal railway booking companion", 13, 0xFF526579, false); root.addView(sub);
        addSpace(root, 16);
        LinearLayout timerCard = card(root);
        timerCard.addView(text("NEXT TATKAL OPENING", 12, 0xFF526579, true));
        countdown = text("Select journey date", 27, 0xFF102A43, true); timerCard.addView(countdown);
        LinearLayout classes = new LinearLayout(this); classes.setOrientation(0); classes.setGravity(Gravity.CENTER_VERTICAL);
        Button ac = smallButton("AC · 10:00 AM"); Button sl = smallButton("SL/2S · 11:00 AM");
        classes.addView(ac, new LinearLayout.LayoutParams(0, dp(46), 1)); classes.addView(sl, new LinearLayout.LayoutParams(0, dp(46), 1)); timerCard.addView(classes);
        ac.setOnClickListener(v -> { hour=10; updateTimer(); }); sl.setOnClickListener(v -> { hour=11; updateTimer(); });
        addSpace(root, 12);
        LinearLayout trip = card(root); trip.addView(text("JOURNEY", 15, 0xFF102A43, true));
        EditText from = field("From station (e.g. KYN)"); from.setText(prefs.getString("from", "KYN")); trip.addView(from);
        EditText to = field("To station (e.g. JNU)"); to.setText(prefs.getString("to", "JNU")); trip.addView(to);
        dateText = text("Journey date: choose date", 15, 0xFF102A43, true); trip.addView(dateText);
        Button date = smallButton("Choose journey date"); trip.addView(date); date.setOnClickListener(v -> chooseDate());
        classGroup = new RadioGroup(this); classGroup.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton slr = new RadioButton(this); slr.setText("Sleeper"); slr.setId(1); slr.setChecked(true);
        RadioButton acr = new RadioButton(this); acr.setText("3AC"); acr.setId(2);
        classGroup.addView(slr); classGroup.addView(acr); trip.addView(classGroup);
        Button save = primary("Save journey details"); trip.addView(save); save.setOnClickListener(v -> {
            prefs.edit().putString("from", from.getText().toString().trim()).putString("to", to.getText().toString().trim()).apply();
            toast("Journey details saved on this device.");
        });
        addSpace(root, 12);
        LinearLayout workflow = card(root); workflow.addView(text("BOOKING WORKFLOW", 15, 0xFF102A43, true));
        String[] steps = {"1. Open official IRCTC website", "2. Select train, date, class and Tatkal quota", "3. Review passenger details", "4. Complete CAPTCHA and OTP yourself", "5. Review fare and pay yourself", "6. Confirm PNR / booking status"};
        for (String s : steps) { CheckBox c = new CheckBox(this); c.setText(s); c.setTextColor(0xFF263746); workflow.addView(c); }
        Button open = primary("Open official IRCTC booking"); workflow.addView(open);
        open.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.irctc.co.in/nget/train-search"))));
        status = text("Security: this app does not collect IRCTC passwords, OTPs, CAPTCHA answers or payment details.", 12, 0xFF526579, false); workflow.addView(status);
        addSpace(root, 12);
        TextView foot = text("Independent companion app. Not affiliated with Indian Railways or IRCTC. Seat availability and booking are confirmed only by IRCTC.", 11, 0xFF657789, false); root.addView(foot);
        setContentView(scroll);
        dateText.setText("Journey date: " + fmt(journey)); updateTimer();
        ticker = new Runnable(){ public void run(){ updateTimer(); handler.postDelayed(this,1000); }}; handler.post(ticker);
    }
    private void chooseDate(){
        Calendar now=Calendar.getInstance();
        new DatePickerDialog(this,(view,y,m,d)->{ journey.set(y,m,d); dateText.setText("Journey date: "+fmt(journey)); updateTimer(); },journey.get(Calendar.YEAR),journey.get(Calendar.MONTH),journey.get(Calendar.DAY_OF_MONTH)).show();
    }
    private void updateTimer(){
        Calendar target=(Calendar)journey.clone(); target.add(Calendar.DAY_OF_MONTH,-1); target.set(Calendar.HOUR_OF_DAY,hour); target.set(Calendar.MINUTE,0); target.set(Calendar.SECOND,0);
        long diff=target.getTimeInMillis()-System.currentTimeMillis();
        if(countdown!=null && diff<=0){ countdown.setText("Tatkal opening time has passed for this journey date"); return; }
        long s=diff/1000; long days=s/86400; s%=86400; long h=s/3600; s%=3600; long m=s/60; s%=60;
        if(countdown!=null) countdown.setText(String.format(Locale.getDefault(),"%d days  %02d:%02d:%02d",days,h,m,s));
    }
    private String fmt(Calendar c){return new SimpleDateFormat("dd MMM yyyy",Locale.getDefault()).format(c.getTime());}
    private LinearLayout card(LinearLayout parent){ LinearLayout l=new LinearLayout(this); l.setOrientation(1); l.setPadding(dp(15),dp(14),dp(15),dp(14)); l.setBackgroundColor(0xFFFFFFFF); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=dp(2); parent.addView(l,p); return l; }
    private TextView text(String s,int size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setPadding(0,dp(4),0,dp(6)); return t; }
    private EditText field(String hint){ EditText e=new EditText(this); e.setSingleLine(true); e.setTextSize(15); e.setHint(hint); e.setPadding(dp(10),0,dp(10),0); return e; }
    private Button smallButton(String s){ Button b=new Button(this); b.setText(s); b.setTextSize(11); return b; }
    private Button primary(String s){ Button b=smallButton(s); b.setTextSize(14); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF1769AA)); b.setTextColor(0xFFFFFFFF); return b; }
    private void addSpace(LinearLayout l,int h){ View v=new View(this); l.addView(v,new LinearLayout.LayoutParams(1,dp(h))); }
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override protected void onDestroy(){super.onDestroy(); if(ticker!=null)handler.removeCallbacks(ticker);}
}
